$(document).ready(function() {
var data = {
"name": "Inigo Montoya",
"age": 29,
"phone": "414-111-2222",
"country": "usa"
    };
var schema = {
"type": "object",
"properties": {
    "name": { "type": "string" },
    "age": { "type": "number", "minimum": 0, "maximum": 50 },
    "phone": { "type": "string" },
    "country": { "type": "string", "required": true } }
    };

var options = {
   "fields": {
          "name": { "type": "text", "label": "Name" },
           "age": { "type": "number", "label": "Age" },
           "phone": { "type": "phone", "label": "Phone" },
            "country": { "type": "country", "label": "Country" }
        },
        "form": {
            "attributes": {
                "method": "POST",
                "action": "http://httpbin.org/post",
                "enctype": "multipart/form-data"
            },
            "buttons": {
                "submit": {
                    "value": "Submit the Form"
                }
            }
        }
    };

var postRenderCallback = function(control) {
  };

    $("#form").alpaca({
        "data": data,
        "schema": schema,
        "options": options,
        "postRender": postRenderCallback,
        //"view": "bootstrap-edit"//,
        "view": "bootstrap-edit-horizontal"
    });
});
